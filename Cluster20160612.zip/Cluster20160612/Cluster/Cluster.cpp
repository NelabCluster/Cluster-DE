#include "Cluster.h"


Cluster::Cluster(void)
{
}


Cluster::~Cluster(void)
{
}
