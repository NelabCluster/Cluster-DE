#pragma once
class Adjust_Tool
{
public:
	Adjust_Tool(void);
	~Adjust_Tool(void);
};

