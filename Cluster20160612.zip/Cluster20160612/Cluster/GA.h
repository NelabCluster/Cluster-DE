#pragma once
class GA
{
public:
	GA(void);
	~GA(void);
};

