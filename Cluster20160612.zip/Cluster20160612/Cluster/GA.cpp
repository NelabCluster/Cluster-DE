#include "GA.h"


GA::GA(void)
{
}


GA::~GA(void)
{
}
