#include "Adjust_Tool.h"


Adjust_Tool::Adjust_Tool(void)
{
}


Adjust_Tool::~Adjust_Tool(void)
{
}
