#pragma once
class Elite_Pool
{
public:
	Elite_Pool(void);
	~Elite_Pool(void);
	static Elite_Pool* openElitePoolWithAtomNumber(int atomN);
	
};

