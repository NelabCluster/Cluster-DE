#pragma once
class Cluster
{
public:



	Cluster(void);
	virtual ~Cluster(void);
};

