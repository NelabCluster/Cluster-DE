#include "Elite_Pool.h"


Elite_Pool::Elite_Pool(void)
{
}


Elite_Pool::~Elite_Pool(void)
{
}
